This repository will allow us to play with the git status command.
