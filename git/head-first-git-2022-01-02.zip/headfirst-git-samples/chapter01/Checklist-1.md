# Getting ready to commit
- [ ] Create checklist
- [ ] Gather initial set of requirements
- [ ] Adopt a litter of puppies for "user testing"
- [ ] Demo first version
