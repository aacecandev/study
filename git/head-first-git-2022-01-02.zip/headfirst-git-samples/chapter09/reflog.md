# Reflog

Reflog stands for reference log.
It is a log of `HEAD` movements. 
