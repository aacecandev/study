# Stashes

A stash is a pseudo-commit.
Stashes are local to your repository! 
