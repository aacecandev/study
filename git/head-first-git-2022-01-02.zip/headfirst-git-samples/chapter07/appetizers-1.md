# Gitanjali and Aref Reception: Appetizers

* Herb-sprinkled stuffed mushrooms
* Blinis with salmon, caviar, and crème fraiche
* Mini roast-beef sandwiches
