# Gitanjali and Aref Reception: Signature Drinks

* Autumn in Manhattan: 
  Pumpkin-spice bitters give a fall feeling to this classic bourbon-vermouth cocktail 
* Orchard Mimosa: 
  Champagne meets apple cider, garnished with a cinnamon-sugar rim
* The Log Cabin: 
  Apple brandy and maple syrup will take you on an autumn trip through our favorite couple’s history

**Nonalcoholic substitutes for all spirits are available upon request.**
