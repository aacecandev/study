The brown fox jumps over the lazy dog
