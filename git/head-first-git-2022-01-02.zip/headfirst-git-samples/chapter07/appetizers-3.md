# Gitanjali and Aref Reception: Appetizers

* Herb-sprinkled stuffed mushrooms
* Blinnis with spiced fruit chutney
* Mini grilled cheese sandwiches
