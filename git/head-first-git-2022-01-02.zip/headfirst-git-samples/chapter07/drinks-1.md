# Gitanjali and Aref Reception: Signature Drinks

* The Manhattan Merge: 
  Two become one in this updated take on a classic bourbon-vermouth cocktail
* The Git Gimlet: 
  Gitanjali’s favorite drink, with refreshing lime and juniper notes 
* The Git Log Cabin: 
  Apple brandy and maple syrup will take you on an autumn trip through our favorite couple’s history 
