# Gitanjali and Aref Reception: Appetizers

* Herb-sprinkled stuffed mushrooms
* Blinnis with spiced fruit and nut chutney
* Mini grilled cheese sandwiches
