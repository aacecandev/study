# Gitanjali and Aref Reception: Dinner Menu

## First course

* Spinach and strawberry salad with champagne dressing

**or**

* Halloumi and grapefruit salad with tahini dressing

## Second course

* Baked Scottish salmon with garlic crumb topping, served with roasted cauliflower and potatoes

**or**

* Beef tenderloin with horseradish sauce, served with a loaded baked potato and green beans

## Dessert

* Chocolate meringue pie

**or**

* Almond-raspberry tart
