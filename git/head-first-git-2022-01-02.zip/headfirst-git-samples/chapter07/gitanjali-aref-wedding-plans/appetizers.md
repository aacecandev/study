# Gitanjali and Aref Reception: Appetizers

* Herb-sprinkled stuffed mushrooms
* Blinnis with spiced fruit chutney
* Mini grilled cheese sandwiches
* Housemade sweet-potato chips topped with French onion dip
* Jackfruit cakes with Old Bay aioli
