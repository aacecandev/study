# Brigitte Strek

## Objective
To leverage my language skills as Chief Communications Officer

## Languages
English (native)
Romulan (beginner)

## Education
Starfleet Academy, San Francisco, CA
Valedictorian, Class of 2018

## Experience
2018-2020, Federation Starship Atlantis - Communications Ensign

Routed incoming subspace communications to the correct officer
