# Spicy Green Mean Machine

## Ingredients
1/2 cup - Plain yogurt
3-4 cloves - Garlic
2 cups - Chopped cilantro
1/4 cup - Olive oil
1/4 cup - Lime juice
2 pinches - Salt
2 - Jalapenos, deseeded

## Instructions
Add all ingredients to a blender. Mix until desired consistency.
