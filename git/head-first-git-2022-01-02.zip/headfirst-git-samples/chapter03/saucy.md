# Call me Cilly

## Ingredients
1/2 cup - Plain yogurt
3-4 cloves - Garlic
2 cups - Chopped cilantro
1/4 cup - Olive oil
1/4 cup - Lime juice
1 pinch - Salt

## Instructions
Add all ingredients to a blender. Mix until smooth.
