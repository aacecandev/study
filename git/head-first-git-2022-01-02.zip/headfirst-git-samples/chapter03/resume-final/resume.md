# Brigitte Strek

## Objective
To leverage my language skills as Chief Communications Officer

## Languages
English (native)
Klingon (fluent)

## Education
Starfleet Academy, San Francisco, CA
Valedictorian, Class of 2018

## Experience
2018-2020, Federation Starship Atlantis - Communications Ensign

Routed all incoming subspace communications to the correct officer
