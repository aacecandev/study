# Tie the Knot

We're taking this party outdoors!
Please come prepared for camping. Here are some things you might want to bring:

* Tent and sleeping bag
* Hiking clothes/boots
* Soap, toothpaste, wipes, lotions
* Hats, backpacks, water bottles, sunscreen, sunglasses

In addition, here is what everyone agreed to get:

* Gitanjali & Aref - Food and drinks
* Maddison & Katreena - Cooking utensils
* Guinna & Logan - Cleaning supplies (detergent, trash bags, etc.)
* Taghrid - Cards, games, and music
* Pushkar - Firewood, matches, paper plates, plasticware
