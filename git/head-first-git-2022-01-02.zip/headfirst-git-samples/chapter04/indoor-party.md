# Love always wins!

It's an engagement party for Gitanjali and Aref!
Join us for a board-game night full of unlimited fun, food and drinks.

Here are just a few of the games we can play:

* Settlers of Catan
* Splendor
* Azul
* Carcassonne
* Scattergories
* Munchkin
* Apples to Apples
* Dragonwood
* Exploding Kittens

Feel free to bring your favorite games.

And remember, as long as we are together, we're all winners.
