# HawtDawg — All Ears

This repository will help us manage the FAQs and documentation for the HawtDawg app.
