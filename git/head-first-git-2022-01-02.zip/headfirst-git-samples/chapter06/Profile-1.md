# Profile

Name: **Roland H. Hermon**

Age: **3**

Breed: **Beagle**

Location: **Philadelphia**
