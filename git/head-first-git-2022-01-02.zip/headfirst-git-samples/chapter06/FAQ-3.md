# FAQ

## How many photos can I post?
 
We know you want to show off your fabulous furry face, so we’ve given you space to upload up to 15 photos! 
For those who are camera-shy, we recommend posting at least one to bring your profile some attention. 
Showcase your best self—whether that means a fresh-from-the-groomer glamour shot or an action shot from your last game of fetch.

## Where do I list my favorite treats?
 
Open the Hawt Dawg app and click on "Edit Profile." 
Scroll down to the section called "Passions" and tell potential mates and friends all about the treats and toys that make your tail wag. 
When you’re done, click “Save Changes” to show the world.

## Photos are nice and all, but I don’t see very well. How can I smell the other dogs?
 
We regret that we are unable to offer our customers smell-o-vision at this time. 
As soon as human technology catches up to dog noses, we’ll be sure to add a scent feature to the app. 
In the meantime, why not meet up at the dog park to get a whiff of your new friend?
