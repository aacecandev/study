# Profile

Name: **Roland H. Hermon**

Age: **3**

Breed: **Beagle**

Location: **Philadelphia**

Skills: Following scent trails, digging holes, treeing squirrels, looking after small children, guarding the pack, stealing chimkin when the little humans isn't looking
