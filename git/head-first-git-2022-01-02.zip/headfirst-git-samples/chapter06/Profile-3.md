# Profile

Name: **Roland H. Hermon**

Age: **3**

Breed: **Beagle**

Location: **Philadelphia**

Turn-offs: Loud noises, helicopters, those little screens the humans look at instead of paying attention to me
