# Fall Menu

## Oat Busters Breakfast Bowl
Deliciously spooky steel-cut oats with stewed pumpkin, warm spices, and candied pecans. This nutritious dish won’t come back to haunt you.

## The Texas Coleslaw Massacre
Slow-cooked Texas-style pulled pork, served with fresh rolls and plenty of our housemade coleslaw. Dangerously good.

## Beetlejuice Bellini
Start your “day-O” with our creepy twist on the classic brunch cocktail: a peach-banana blend spiked with prosecco. Guaranteed to exorcise your hangover.
