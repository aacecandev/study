# Throwback Thursdays

## The Breakfast Club Sandwich
A club that breaks the rules: ham, bacon, turkey, and tomato plus a fried egg, all between layers of toast.

## Footloose Burger
A juicy grilled Black Angus quarter-pounder with American cheese and plenty of bacon.

## Fried Green Tomatoes
OK, it’s from 1991, but we bet you can’t resist these tart, juicy slices of cornmeal-crusted Southern bliss.
