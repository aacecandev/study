# The '80s Diner

## Top Gumbo
You’ll be ready to brave the heights after this hearty, spicy Southern-style seafood-and-okra stew.

## Mac to the Future
Mix the '80s with the '50s with our classic baked mac and cheese, handmade with a five-cheese blend and topped with buttery breadcrumbs.

## Raiders of the Lost Tarka Dal
Take a trip to India with Dr. Jones’s favorite creamy lentils, fragrant with spices. Vegetarian!
