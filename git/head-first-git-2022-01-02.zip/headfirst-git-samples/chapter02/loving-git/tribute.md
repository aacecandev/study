# Tribute to Git
There's a version control tool called Git
When you feel like you just want to quit
Go and try something new
You can track what you do
Since you've got a great tracking kit.
