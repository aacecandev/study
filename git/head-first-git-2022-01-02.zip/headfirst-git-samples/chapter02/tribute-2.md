# Tribute to Git
There's a version control tool called Git
For software it's an excellent fit
If your attitude ranges
Feel free to make changes
Since you've got a great tracking kit.
