# Making your life easier with Git

1. You can override the global configuration on a per-repository basis
